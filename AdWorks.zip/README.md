Ubuntu 10.04 LTS
GNU Make 3.81
g++ (Ubuntu 4.4.3-4ubuntu5.1) 4.4.3
NetBeans IDE 7.2.1
boost 1.52.0
